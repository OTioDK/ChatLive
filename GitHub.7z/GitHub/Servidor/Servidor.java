package com.ChatLive.app;

import com.ChatLive.app.service.ServidorService;


public class Servidor {

    public static void main(String[] args) {
        new ServidorService();
    }
}
